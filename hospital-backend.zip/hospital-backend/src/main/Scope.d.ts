     'distance' => '50800',
                'direction' => '2700000',
            ],
            11 => [
                'effect' => 'innerShdw',
                'blur' => '63500',
                'distance' => '50800',
                'direction' => '5400000',
            ],
            12 => [
                'effect' => 'innerShdw',
                'blur' => '63500',
                'distance' => '50800',
                'direction' => '8100000',
            ],
            13 => [
                'effect' => 'innerShdw',
                'blur' => '63500',
                'distance' => '50800',
            ],
            14 => [
                'effect' => 'innerShdw',
                'blur' => '114300',
            ],
            15 => [
                'effect' => 'innerShdw',
                'blur' => '63500',
                'distance' => '50800',
                'direction' => '10800000',
            ],
            16 => [
                'effect' => 'innerShdw',
                'blur' => '63500',
                'distance' => '50800',
                'direction' => '18900000',
            ],
            17 => [
                'effect' => 'innerShdw',
                'blur' => '63500',
                'distance' => '50800',
                'direction' => '16200000',
            ],
            18 => [
                'effect' => 'innerShdw',
                'blur' => '63500',
                'distance' => '50800',
                'direction' => '13500000',
            ],
            //perspective
            19 => [
                'effect' => 'outerShdw',
                'blur' => '152400',
                'distance' => '317500',
                'size' => [
                    'sx' => '90000',
                    'sy' => '-19000',
                ],
                'direction' => '5400000',
                'rotWithShape' => '0',
            ],
            20 => [
                'effect' => 'outerShdw',
                'blur' => '76200',
                'direction' => '18900000',
                'size' => [
                    'sy' => '23000',
                    'kx' => '-1200000',
                ],
                'algn' => 'bl',
                'rotWithShape' => '0',
            ],
            21 => [
                'ef